# main.py

import streamlit as st
from PIL import Image
import io
import os
import pandas as pd
import time

# Import your existing modules
from ocr_preprocessor import ImprovedAadhaarOCRProcessor
from format_validator import AadhaarFormatValidator
from fraud_detector import AadhaarFraudDetector
from model import predict_aadhar  # your function to load .pth and predict
from utils import append_log, read_logs  # optional helpers
from visualize import visualize_aadhar_fields  # make a version that returns image array

# Initialize processors
ocr_processor = ImprovedAadhaarOCRProcessor()
format_validator = AadhaarFormatValidator()
fraud_detector = AadhaarFraudDetector()

# --- Streamlit Page Config ---
st.set_page_config(page_title="Aadhaar Verification Dashboard", layout="wide")
st.title("📇 Aadhaar Verification Dashboard")

# --- Sidebar Input ---
st.sidebar.header("Input Options")
input_option = st.sidebar.radio("Choose Input Method", ["Upload Image", "Use Camera", "Enter Aadhaar Number"])

image_bytes = None
aadhaar_number_input = None

if input_option == "Upload Image":
    uploaded_file = st.sidebar.file_uploader("Upload Aadhaar image", type=["jpg", "png", "jpeg"])
    if uploaded_file is not None:
        image_bytes = uploaded_file.read()

elif input_option == "Use Camera":
    captured_image = st.sidebar.camera_input("Capture Aadhaar image")
    if captured_image is not None:
        image_bytes = captured_image.read()

else:
    aadhaar_number_input = st.sidebar.text_input("Enter Aadhaar Number")

# --- Processing Function ---
def process_image(image_bytes):
    # Run OCR
    ocr_results = ocr_processor.process_aadhaar_document_improved(image_bytes)
    
    # Format validation
    format_results = format_validator.validate_document_format(image_bytes)
    
    # Fraud scoring
    fraud_results = fraud_detector.calculate_fraud_score(ocr_results, format_results, image_bytes)
    
    # Classification using trained model
    label = predict_aadhar(image_bytes)
    
    return {
        "ocr_results": ocr_results,
        "format_results": format_results,
        "fraud_results": fraud_results,
        "model_label": label
    }

# --- Display Results ---
if image_bytes is not None:
    results = process_image(image_bytes)

    # Show original image
    st.subheader("Original Image")
    st.image(image_bytes, use_container_width=True)

    # Visualize processed OCR fields
    st.subheader("Processed / Highlighted Fields")
    visualized_img = visualize_aadhar_fields(image_bytes)  # ensure it returns np.array
    st.image(visualized_img, use_container_width=True)

    # Display extracted info
    st.subheader("Detection Results")
    ocr_info = results["ocr_results"]
    fraud_info = results["fraud_results"]

    st.markdown(f"**Name:** {ocr_info.get('name', 'N/A')}")
    st.markdown(f"**DOB:** {ocr_info.get('dob', 'N/A')}")
    st.markdown(f"**Aadhaar Number:** {ocr_info.get('aadhaar_number', 'N/A')}")
    st.markdown(f"**Status (Model Prediction):** {results['model_label']}")
    st.markdown(f"**Fraud Score:** {fraud_info['fraud_score']:.2f}")
    st.json(fraud_info["component_scores"])

    # --- Logging ---
    append_log({
        "timestamp": time.time(),
        "aadhaar_number": ocr_info.get("aadhaar_number", "N/A"),
        "status": results['model_label'],
        "fraud_score": fraud_info['fraud_score']
    }, log_file="logs.csv")

# --- Statistics Panel ---
st.sidebar.header("Statistics")
if os.path.exists("logs.csv"):
    df_logs = pd.read_csv("logs.csv")
    st.sidebar.metric("Total Images Processed", len(df_logs))
    st.sidebar.metric("Real Aadhaar", len(df_logs[df_logs['status'] == "Real Aadhaar"]))
    st.sidebar.metric("Fake Aadhaar", len(df_logs[df_logs['status'] == "Fake Aadhaar"]))
    st.sidebar.subheader("Recent Logs")
    st.sidebar.dataframe(df_logs.tail(5))







    