import cv2
import numpy as np
class AadhaarFormatValidator:
    def __init__(self):
        self.required_elements = {
            'qr_code': 0.3,
            'logo': 0.2,
            'security_features': 0.2,
            'proper_layout': 0.3
        }

    def detect_qr_code(self, image_path):
        """Detect QR code in the Aadhaar image."""
        try:
            img = cv2.imread(image_path)
            if img is None:
                return False
            qr_detector = cv2.QRCodeDetector()
            _, bbox, _ = qr_detector.detectAndDecode(img)
            return bbox is not None and len(bbox) > 0
        except:
            return False
    

    # --- NEW FUNCTION: Basic Tamper Detection (Pixel Difference) ---
    def detect_pixel_tampering(self, image_path):
        """
        A simplified check for high-contrast, localized changes (common for paste-overs).
        """
        try:
            img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                return 0.0 # No image
                
            # Compute a measure of local color/pixel variance (e.g., standard deviation over blocks)
            # Simple approach: compute difference between median and mean filtered image
            median = cv2.medianBlur(img, 5)
            mean = cv2.blur(img, (5, 5))
            
            diff = cv2.absdiff(median, mean)
            
            # Count the number of significantly different pixels (potential tamper spots)
            _, thresh = cv2.threshold(diff, 50, 255, cv2.THRESH_BINARY)
            
            tamper_ratio = np.sum(thresh > 0) / (img.shape[0] * img.shape[1])
            
            # Map ratio to a tamper score (higher ratio = higher tamper score)
            tamper_score = min(tamper_ratio * 10, 1.0) # Scale and cap at 1.0
            
            return tamper_score 
        except:
            return 0.5 # Neutral score on error
    def detect_logo(self, image_path):
        """Detect Aadhaar logo (simplified using edges)."""
        try:
            img = cv2.imread(image_path)
            if img is None:
                return False
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            height, width = edges.shape
            roi = edges[height//10:height//3, width//3:2*width//3]
            edge_density = np.sum(roi > 0) / (roi.shape[0] * roi.shape[1])
            return edge_density > 0.01
        except:
            return False

    def analyze_image_quality(self, image_path):
        """Evaluate blur and contrast of the Aadhaar image."""
        try:
            img = cv2.imread(image_path)
            if img is None:
                return {'blur_score': 0.0, 'contrast_score': 0.0, 'quality_score': 0.0}

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            blur_score = cv2.Laplacian(gray, cv2.CV_64F).var()
            normalized_blur = min(blur_score / 500.0, 1.0)
            normalized_blur = max(normalized_blur, 0.4)  # minimum score

            contrast_score = (gray.max() - gray.min()) / 255.0
            contrast_score = max(min(contrast_score, 1.0), 0.4)

            quality_score = 0.5 * normalized_blur + 0.5 * contrast_score
            return {'blur_score': normalized_blur, 'contrast_score': contrast_score, 'quality_score': quality_score}
        except:
            return {'blur_score': 0.0, 'contrast_score': 0.0, 'quality_score': 0.0}

    def check_layout_consistency(self, image_path):
        """Check if the Aadhaar card has proper layout and text regions."""
        try:
            img = cv2.imread(image_path)
            if img is None:
                return False
            height, width = img.shape[:2]
            aspect_ratio = width / height
            proper_aspect = 1.4 <= aspect_ratio <= 2.0

            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            text_region_ratio = np.sum(thresh < 128) / (height * width)
            sufficient_text = text_region_ratio > 0.03  # relaxed threshold

            return proper_aspect and sufficient_text
        except:
            return False

    def validate_document_format(self, image_path):
        """Full format validation with scoring."""
        qr_detected = self.detect_qr_code(image_path)
        logo_detected = self.detect_logo(image_path)
        quality_metrics = self.analyze_image_quality(image_path)
        proper_layout = self.check_layout_consistency(image_path)
        tamper_score = self.detect_pixel_tampering(image_path)
        qr_detected = self.detect_qr_code(image_path)
        format_score = (
            self.required_elements['qr_code'] * qr_detected +
            self.required_elements['logo'] * logo_detected +
            self.required_elements['security_features'] * 0.5 +  # simplified
            self.required_elements['proper_layout'] * proper_layout
        )

        return {
            'qr_detected': qr_detected,
            'logo_detected': logo_detected,
            'blur_score': quality_metrics['blur_score'],
            'contrast_score': quality_metrics['contrast_score'],
            'quality_score': quality_metrics['quality_score'],
            'tamper_score': tamper_score,
            'proper_layout': proper_layout,
            'format_score': format_score,
            'format_valid': format_score >= 0.6  # threshold for valid format
        }

# Initialize validator
format_validator = AadhaarFormatValidator()
