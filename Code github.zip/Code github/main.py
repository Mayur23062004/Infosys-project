import streamlit as st
from PIL import Image
import os, time, cv2, numpy as np, pandas as pd
import pytesseract

# Set Tesseract path
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

# Import project modules
from ocr_preprocessor import ImprovedAadhaarOCRProcessor
from format_validator import AadhaarFormatValidator
from fraud_detector import AadhaarFraudDetector
from model import predict_aadhar
from utils import append_log, read_logs, save_bytes_to_file

# Initialize modules
ocr_processor = ImprovedAadhaarOCRProcessor()
format_validator = AadhaarFormatValidator()
fraud_detector = AadhaarFraudDetector()

# Ensure uploads folder exists
os.makedirs("uploads", exist_ok=True)

# ----------------- Streamlit Config -----------------
st.set_page_config(page_title="Aadhaar Verification Dashboard", layout="wide")

# ----------------- Global Styling (Compact) -----------------
st.markdown("""
<style>

/******** GLOBAL ********/
body {
    background-color: #FAFAFA;
    font-family: 'Segoe UI';
}

/******** TITLE ********/
h1 {
    background-color: #0078D7;
    color: #ffffff;
    padding: 6px 10px;
    margin-bottom: 5px;
    font-size: 30px;
    border-radius: 6px;
    text-align: center;
}

/******** CONTENT WIDTH ********/
main .block-container {
    max-width: 1100px;
    padding-top: 0.5rem;
}

/******** UPLOAD BOX ********/
.upload-box {
    border: 2px dashed #0078D7;
    border-radius: 6px;
    padding: 12px;
    background-color: #F0F8FF;
    text-align: center;
    font-size: 14px;
}
.upload-box:hover { background-color: #E6F3FF; }

/******** BUTTON ********/
div.stButton > button {
    background-color: #0078D7;
    color: white;
    font-size: 14px;
    border-radius: 6px;
    padding: 6px 14px;
}
div.stButton > button:hover {
    background-color: #005fa3;
}

/******** RESULT BOX ********/
.result-box {
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    margin-top: 10px;
}
.result-box h3 {
    margin: 0;
    font-size: 22px;
}
.result-box p {
    margin: 4px 0 0 0;
    font-size: 14px;
}

/******** IMAGES ********/
img {
    border-radius: 6px;
    max-height: 280px !important;
    object-fit: contain;
}

</style>
""", unsafe_allow_html=True)

# ----------------- Title -----------------
st.title("Aadhaar Verification & Fraud Detection")

# ----------------- Sidebar Stats -----------------
df_logs = read_logs("logs.csv")
st.sidebar.title("📊 Statistics")

if not df_logs.empty:
    total = len(df_logs)
    real = len(df_logs[df_logs['status']=="Real Aadhaar"])
    fake = len(df_logs[df_logs['status']=="Fake Aadhaar"])
else:
    total = real = fake = 0

st.sidebar.metric("Total Processed", total)
st.sidebar.metric("Real Aadhaar", real)
st.sidebar.metric("Fake Aadhaar", fake)

if not df_logs.empty:
    st.sidebar.subheader("Recent Logs")
    st.sidebar.dataframe(df_logs.tail(5), use_container_width=True)
    st.sidebar.subheader("Aadhaar Status Chart")
    st.sidebar.bar_chart(df_logs['status'].value_counts())

# ----------------- Input Section -----------------
st.subheader("1️⃣ Provide Aadhaar Input")

input_option = st.radio(
    "Select Method",
    ["Upload Image", "Use Camera", "Enter Aadhaar Number"],
    horizontal=True
)

image_bytes, aadhaar_number_input = None, None

if input_option == "Upload Image":
    st.markdown('<div class="upload-box">🖼️ Upload Aadhaar Image</div>', unsafe_allow_html=True)
    uploaded_file = st.file_uploader("", type=["jpg", "jpeg", "png"])
    if uploaded_file:
        image_bytes = uploaded_file.read()

elif input_option == "Use Camera":
    captured_image = st.camera_input("📸 Capture Aadhaar Image")
    if captured_image:
        image_bytes = captured_image.read()

else:
    aadhaar_number_input = st.text_input("🔢 Enter Aadhaar Number")

st.info("Upload or capture a clear Aadhaar image for best accuracy.")

# ----------------- OCR Visualization Helper -----------------
@st.cache_data(show_spinner=False)
def visualize_aadhaar_fields(ocr_results, temp_path):
    image = cv2.imread(temp_path)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    for bbox, text, conf in ocr_results['easyocr_boxes']:
        if any(k in text.upper() for k in ['UIDAI', 'INDIA', 'DOB', 'BIRTH', 'MALE', 'FEMALE', 'आधार']) or any(c.isdigit() for c in text):
            pts = np.array(bbox, np.int32)
            cv2.polylines(image, [pts], True, (0, 255, 0), 2)
    return image

# ----------------- Combined Verification -----------------
@st.cache_data(show_spinner=False)
def combined_verification(image_bytes):
    temp_path = save_bytes_to_file(image_bytes, folder="uploads", filename="temp_aadhaar.jpg")

    ocr_results = ocr_processor.process_aadhaar_document_improved(temp_path)
    format_results = format_validator.validate_document_format(temp_path)
    fraud_results = fraud_detector.calculate_fraud_score(ocr_results, format_results, temp_path)

    model_label, model_conf = predict_aadhar(image_bytes)

    combined_score = 0.2 * fraud_results['fraud_score'] + 0.8 * model_conf
    final_label = "Fake Aadhaar" if combined_score >= 0.5 else "Real Aadhaar"

    return {
        'final_label': final_label,
        'combined_score': combined_score,
        'fraud_results': fraud_results,
        'ocr_results': ocr_results,
        'model_label': model_label,
        'temp_path': temp_path
    }

# ----------------- Run Verification -----------------
st.markdown("<br>", unsafe_allow_html=True)
verify_button = st.button("Run Verification")

if verify_button:
    if not image_bytes and not aadhaar_number_input:
        st.warning("Please provide an Aadhaar image or number.")
    else:
        with st.spinner("⏳ Processing Aadhaar document..."):
            result = combined_verification(image_bytes)

        # Images row (compact)
        col1, col2 = st.columns([1, 1])
        with col1:
            st.markdown("### Original Image")
            st.image(image_bytes, use_container_width=True)

        with col2:
            st.markdown("### Detected Fields")
            st.image(
                visualize_aadhaar_fields(result['ocr_results'], result['temp_path']),
                use_container_width=True
            )

        st.markdown("<hr>", unsafe_allow_html=True)

        # Result Box
        st.subheader("Verification Summary")
        color = "#4CAF50" if result['final_label']=="Real Aadhaar" else "#F44336"
        icon = "✅" if result['final_label']=="Real Aadhaar" else "❌"

        st.markdown(f"""
        <div class="result-box" style='background-color:{color};'>
            <h3 style='color:white;'>{icon} {result['final_label']}</h3>
            <p style='color:white;'>Confidence: {result['combined_score']*100:.2f}%</p>
        </div>
        """, unsafe_allow_html=True)

        # Details Row
        colA, colB = st.columns(2)

        with colA:
            with st.expander("📋 Extracted Fields", expanded=True):
                st.json({
                    "Name": result['ocr_results'].get('name','N/A'),
                    "DOB": result['ocr_results'].get('dob','N/A'),
                    "Gender": result['ocr_results'].get('gender','N/A'),
                    "Aadhaar Number": result['ocr_results'].get('aadhaar_number','N/A')
                })

        with colB:
            with st.expander("📊 Fraud Score Details", expanded=True):
                st.json(result['fraud_results'].get("component_scores", {}))
            st.info(f"ResNet Model Prediction: {result['model_label']}")

        # Logging
        append_log({
            "timestamp": time.time(),
            "aadhaar_number": result['ocr_results'].get("aadhaar_number", "N/A"),
            "status": result['final_label'],
            "fraud_score": result['combined_score']
        }, log_file="logs.csv")
