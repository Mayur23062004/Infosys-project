import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import io
import os

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def build_resnet18(num_classes=2):
    model = models.resnet18(pretrained=False)
    model.fc = nn.Linear(model.fc.in_features, num_classes)
    return model

MODEL_PATH = os.path.join("model_load", "aadhar_resnet_model.pth")

model = build_resnet18(num_classes=2).to(device)
state = torch.load(MODEL_PATH, map_location=device)
# state may be state_dict
if isinstance(state, dict):
    try:
        model.load_state_dict(state)
    except RuntimeError:
        # handle if saved with "module." prefixes
        new_state = {}
        for k, v in state.items():
            nk = k.replace("module.", "") if k.startswith("module.") else k
            new_state[nk] = v
        model.load_state_dict(new_state)
else:
    # If entire model object saved, try assign (rare)
    model = state.to(device)

model.eval()

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406], [0.229,0.224,0.225])
])

def predict_aadhar(image_bytes):
    """
    input: image_bytes (uploaded_file.read())
    returns: label (str), confidence (float probability of predicted class)
    """
    # write temp file
    tmp = os.path.join("model_load", "_tmp_input.jpg")
    with open(tmp, "wb") as f:
        f.write(image_bytes)

    img = Image.open(tmp).convert("RGB")
    tensor = transform(img).unsqueeze(0).to(device)

    with torch.no_grad():
        out = model(tensor)
        probs = torch.softmax(out, dim=1)[0]
    # choose predicted class
    conf, pred = torch.max(probs, dim=0)
    # label mapping: earlier you trained with ImageFolder — class 0 -> real, 1 -> fake
    label = "Real Aadhaar" if int(pred.item()) == 0 else "Fake Aadhaar"
    return label, float(conf.item())
