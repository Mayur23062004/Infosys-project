import cv2
import numpy as np
from fraud_image_utils import FraudImageUtils
from tampering_model import TamperingModelWrapper

class AadhaarFraudDetector:
    def __init__(self):
        self.cv_utils = FraudImageUtils()
        self.tamper_model = TamperingModelWrapper()  # looks for model_load/tampering.pth

        # weights (you can tune)
        self.weights = {
            "dl_tamper": 0.5,
            "cv_forgery": 0.25,
            "format_score": 0.15,
            "ocr_penalty": 0.10
        }
        self.fraud_threshold = 0.5

    def calculate_fraud_score(self, ocr_results, format_results, image_path=None, label=None):
        """
        Inputs:
          - ocr_results: dict from OCR processor
          - format_results: dict from format validator (must include 'format_score' and 'tamper_score' if present)
          - image_path: path to saved image
        Returns dict with keys:
          'fraud_score', 'is_fraudulent', 'component_scores', 'final_prediction'
        """
        img = None
        if image_path:
            img = cv2.imread(image_path)
        else:
            # if no image path provided, create dummy zeros
            img = np.zeros((224, 224, 3), dtype=np.uint8)

        # 1) Deep learning tamper model
        dl_tamper_score = self.tamper_model.detect(img)  # 0..1

        # 2) CV heuristics (copy-move, edge, jpeg, font, noise)
        copy_move = self.cv_utils.detect_copy_move(img)
        edge_incons = self.cv_utils.edge_inconsistency(img)
        jpeg_art = self.cv_utils.jpeg_artifacts(img)
        font_incons = self.cv_utils.font_inconsistency(img)
        noise = self.cv_utils.noise_level(img)
        cv_components = {
            "copy_move": copy_move,
            "edge_inconsistency": edge_incons,
            "jpeg_artifacts": jpeg_art,
            "font_inconsistency": font_incons,
            "noise_level": noise
        }
        cv_forgery_score = float(np.mean(list(cv_components.values())))

        # 3) Format validator's tamper_score (pixel tamper) and format_score
        tamper_from_format = float(format_results.get("tamper_score", 0.0))
        format_score = float(format_results.get("format_score", 0.0))

        # 4) OCR-based penalties (missing fields / aadhaar invalid)
        text_penalty = 0.0
        if not ocr_results.get("aadhaar_valid", False):
            text_penalty += 0.5
        missing = 0
        for f in ["name", "dob"]:
            if ocr_results.get(f, "N/A") in ("", "N/A"):
                missing += 1
        text_penalty += 0.15 * missing
        if ocr_results.get("text_length", 0) < 50:
            text_penalty += 0.15
        text_penalty = min(text_penalty, 1.0)

        # 5) Face presence (from CV utils) — higher missing face => penalty
        face_score = self.cv_utils.detect_face_presence_score(img)  # 0..1 (1 means face found)
        face_penalty = 1.0 - face_score

        # Aggregate CV combined score (include tamper_from_format to increase sensitivity)
        combined_cv_score = (cv_forgery_score + tamper_from_format + face_penalty) / 3.0

        # Final weighted fraud score
        fraud_score = (
            self.weights["dl_tamper"] * dl_tamper_score +
            self.weights["cv_forgery"] * combined_cv_score +
            self.weights["format_score"] * (1.0 - format_score) +  # lower format_score => higher risk
            self.weights["ocr_penalty"] * text_penalty
        )
        fraud_score = float(max(0.0, min(fraud_score, 1.0)))

        result = {
            "fraud_score": fraud_score,
            "is_fraudulent": fraud_score >= self.fraud_threshold,
            "component_scores": {
                "dl_tamper_score": dl_tamper_score,
                "cv_forgery_score": cv_forgery_score,
                "format_score": format_score,
                "ocr_penalty": text_penalty,
                "face_penalty": face_penalty,
                **cv_components,
                "tamper_from_format": tamper_from_format
            },
            "final_prediction": 1 if fraud_score >= self.fraud_threshold else 0
        }

        if label is not None:
            result["actual_label"] = label
            result["correct_prediction"] = result["final_prediction"] == label

        return result
