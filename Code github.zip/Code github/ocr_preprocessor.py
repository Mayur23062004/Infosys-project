import cv2
import re
import numpy as np
import easyocr

class ImprovedAadhaarOCRProcessor:
    def __init__(self):
        self.essential_elements = [
            'government of india', 'uidai', 'aadhaar', 'unique identification authority of india'
        ]
        self.reader = easyocr.Reader(['en', 'hi'])  # Initialize once
        self.gender_keywords = ["MALE", "FEMALE", "TRANSGENDER", "पुरुष", "महिला"]

    def preprocess_image(self, image_path):
        img = cv2.imread(image_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (3,3), 0)
        gray = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        return gray

    def validate_aadhaar(self, text):
        patterns = [
            r'\b\d{4}\s?\d{4}\s?\d{4}\b',
            r'\b\d{12}\b',
            r'\b\d{4}-\d{4}-\d{4}\b'
        ]
        for pattern in patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                aadhaar_clean = re.sub(r'[^\d]', '', match)
                if len(aadhaar_clean) == 12:
                    return True, aadhaar_clean
        return False, None

    def detect_essential_elements(self, text):
        detected = []
        text_lower = text.lower()
        elements_flexible = {
            'government of india': ['government of india', 'govt of india', 'भारत सरकार'],
            'uidai': ['uidai', 'unique identification authority'],
            'aadhaar': ['aadhaar', 'aadhar', 'आधार'],
            'my_aadhaar': ['mera aadhaar', 'meri pehchan', 'मेरा आधार', 'मेरी पहचान']
        }
        for element, variants in elements_flexible.items():
            for var in variants:
                if var in text_lower:
                    detected.append(element)
                    break
        return detected

    def extract_details_from_boxes(self, ocr_results):
        details = {'name':'N/A', 'dob':'N/A', 'gender':'N/A', 'aadhaar_number':'N/A'}

        # Sort boxes top to bottom
        boxes_sorted = sorted(ocr_results, key=lambda x: min([pt[1] for pt in x[0]]))

        # Combined DOB regex: keyword + date
        dob_pattern = re.compile(
            r'(?:DOB|Year\s+of\s+Birth|YOB|जन्म\s+तिथि|जन्म\s+तारीख)[\s:]*'
            r'((0[1-9]|[12][0-9]|3[01])[-/](0[1-9]|1[0-2])[-/](19|20)\d{2}|\d{4})',
            re.IGNORECASE
        )

        # Generic date fallback (if no keyword)
        date_pattern = re.compile(r'\b(0[1-9]|[12][0-9]|3[01])[-/](0[1-9]|1[0-2])[-/](19|20)\d{2}\b')

        for bbox, text, conf in boxes_sorted:
            text_clean = text.strip()

            # --- DOB Extraction ---
            if details['dob'] == 'N/A':
                dob_match = dob_pattern.search(text_clean)
                if dob_match:
                    details['dob'] = dob_match.group(1).strip()
                else:
                    # Fallback: detect any valid date format
                    fallback_match = date_pattern.search(text_clean)
                    if fallback_match:
                        details['dob'] = fallback_match.group(0)

            # --- Gender ---
            for g in self.gender_keywords:
                if g.upper() in text_clean.upper():
                    if g in ['पुरुष', 'Male']:
                        details['gender'] = 'Male'
                    elif g in ['महिला', 'Female']:
                        details['gender'] = 'Female'
                    else:
                        details['gender'] = g  # Transgender etc.

            # --- Aadhaar Number ---
            aadhaar_valid, aadhaar_number = self.validate_aadhaar(text_clean)
            if aadhaar_valid:
                details['aadhaar_number'] = aadhaar_number

        # --- Name extraction: nearest box above DOB ---
        if details['dob'] != 'N/A':
            dob_box_index = next((i for i, x in enumerate(boxes_sorted) if details['dob'] in x[1]), None)
            if dob_box_index is not None and dob_box_index > 0:
                candidate = boxes_sorted[dob_box_index - 1][1].strip()
                if len(candidate) > 3 and not re.search(r'(Aadhaar|संख्या|DOB|जन्म)', candidate, re.IGNORECASE):
                    details['name'] = candidate

        return details



    def process_aadhaar_document_improved(self, image_path):
        """Main OCR function"""
        img = cv2.imread(image_path)
        ocr_results = self.reader.readtext(img)  # EasyOCR output: list of (bbox, text, conf)

        # Combine all text for fraud scoring, essential elements detection
        full_text = "\n".join([text for _, text, _ in ocr_results])

        # Extract structured fields from boxes
        extracted_details = self.extract_details_from_boxes(ocr_results)

        # Aadhaar number validation fallback
        aadhaar_valid, aadhaar_number = self.validate_aadhaar(full_text)
        if extracted_details['aadhaar_number'] == 'N/A' and aadhaar_valid:
            extracted_details['aadhaar_number'] = aadhaar_number

        # Essential elements
        essential_elements = self.detect_essential_elements(full_text)

        result = {
            'raw_text': full_text,
            'aadhaar_number': extracted_details['aadhaar_number'],
            'aadhaar_valid': aadhaar_valid,
            'essential_elements_detected': essential_elements,
            'text_length': len(full_text),
            **extracted_details,
            'easyocr_boxes': ocr_results  # For visualization
        }

        return result
