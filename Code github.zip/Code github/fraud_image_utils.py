import cv2
import numpy as np

class FraudImageUtils:
    """Collection of CV-based forgery / tamper heuristics used by Module-3."""

    def detect_copy_move(self, image):
        """
        Quick block-correlation method. Returns score in 0..1 (higher = more likely copy-move).
        Not perfect but useful as a heuristic.
        """
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, (256, 256))
            h, w = small.shape
            blocks = []
            step = 16
            blk = 32
            for y in range(0, h - blk + 1, step):
                for x in range(0, w - blk + 1, step):
                    b = small[y:y+blk, x:x+blk].flatten()
                    blocks.append(b)
            blocks = np.array(blocks, dtype=np.float32)
            if blocks.shape[0] < 10:
                return 0.0
            # compute correlation matrix (sampled)
            # to keep cheap, compare only first 200 blocks
            sample = blocks[:200]
            corr = np.corrcoef(sample)
            np.fill_diagonal(corr, 0)
            max_sim = float(np.max(corr))
            return min(max_sim, 1.0)
        except Exception:
            return 0.0

    def edge_inconsistency(self, image):
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 80, 200)
            return min(np.var(edges) / 5000.0, 1.0)
        except Exception:
            return 0.0

    def jpeg_artifacts(self, image):
        try:
            # estimate blockiness via DCT magnitude mean
            y = cv2.cvtColor(image, cv2.COLOR_BGR2YCrCb)[:, :, 0].astype(np.float32)
            # downsample for speed
            y_small = cv2.resize(y, (128, 128))
            # simple DCT per 8x8 block average magnitude
            total = 0.0
            count = 0
            for i in range(0, 128, 8):
                for j in range(0, 128, 8):
                    block = y_small[i:i+8, j:j+8]
                    d = cv2.dct(block)
                    total += np.mean(np.abs(d))
                    count += 1
            mean_dct = total / (count + 1e-9)
            return min(mean_dct / 200.0, 1.0)
        except Exception:
            return 0.0

    def font_inconsistency(self, image):
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            # Otsu threshold to get text blobs
            _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            heights = [cv2.boundingRect(c)[3] for c in contours if cv2.boundingRect(c)[3] > 8]
            if len(heights) < 5:
                return 0.0
            inconsistency = np.std(heights) / (np.mean(heights) + 1e-9)
            return min(inconsistency, 1.0)
        except Exception:
            return 0.0

    def noise_level(self, image):
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            noise = cv2.Laplacian(gray, cv2.CV_64F).var()
            return min(noise / 2000.0, 1.0)
        except Exception:
            return 0.0

    def detect_face_presence_score(self, image):
        """
        Returns fraction of detected faces (0..1). Uses Haar cascade included with OpenCV.
        """
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=4, minSize=(30, 30))
            if len(faces) == 0:
                return 0.0
            # We expect exactly one small face area on Aadhaar — if multiple, give partial credit
            return min(len(faces) / 2.0, 1.0)
        except Exception:
            return 0.0
