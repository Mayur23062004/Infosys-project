import torch
import torch.nn as nn
import cv2
import numpy as np

class TamperingNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.ReLU(), nn.AdaptiveAvgPool2d(1)
        )
        self.fc = nn.Linear(128, 1)

    def forward(self, x):
        x = self.features(x).view(x.size(0), -1)
        return torch.sigmoid(self.fc(x))

class TamperingModelWrapper:
    def __init__(self, model_path="model_load/tampering.pth", device="cpu"):
        self.device = torch.device(device)
        self.model = TamperingNet().to(self.device)
        try:
            state = torch.load(model_path, map_location=self.device)
            # accept both state_dict or full model
            if isinstance(state, dict) and any(k.startswith("features") or k.startswith("fc") for k in state.keys()):
                self.model.load_state_dict(state)
            else:
                # if whole model saved, try load_state_dict key mismatch handling
                try:
                    self.model.load_state_dict(state)
                except Exception:
                    # fallback: ignore and use untrained model
                    pass
        except Exception:
            # file missing or load failed -> untrained model (graceful)
            pass
        self.model.eval()

    def detect(self, image_bgr):
        """
        image_bgr: np.ndarray (H,W,3) BGR uint8
        returns float in 0..1
        """
        try:
            img = cv2.resize(image_bgr, (128, 128))
            img = img[:, :, ::-1]  # BGR -> RGB
            img = img.astype("float32") / 255.0
            img = np.transpose(img, (2, 0, 1))[None, ...]
            import torch
            tensor = torch.from_numpy(img).to(self.device)
            with torch.no_grad():
                out = self.model(tensor)
                return float(out.item())
        except Exception:
            return 0.0
